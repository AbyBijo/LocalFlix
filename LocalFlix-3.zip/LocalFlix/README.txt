LocalFlix - AIDE project
1. Extract zip. Folder "LocalFlix" must contain AndroidManifest.xml and src/.
2. AIDE > Open > navigate into LocalFlix folder > open project.
3. Run (play button) > Install > Allow video permission.
res/drawable/ic_launcher.png is the only resource (plain PNG).
